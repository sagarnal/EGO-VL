from __future__ import annotations

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    rows = list(csv.DictReader((ROOT / "results" / "analytical_results.csv").open(newline="", encoding="utf-8")))
    assert [int(row["k_local"]) for row in rows] == [8, 12, 16, 24, 49]
    full_pairs = 50**2
    for row in rows:
        k = int(row["k_local"])
        pairs = (k + 1) ** 2
        reduction = 100.0 * (full_pairs - pairs) / full_pairs
        assert int(row["ordered_attention_pairs"]) == pairs
        assert math.isclose(float(row["pair_reduction_vs_full_percent"]), reduction, abs_tol=0.005)
    timing = list(csv.DictReader((ROOT / "results" / "pilot_timing_interpretation.csv").open(newline="", encoding="utf-8")))
    mixer = timing[0]
    full_path = timing[1]
    assert math.isclose(float(mixer["change_percent"]), -41.239, abs_tol=0.001)
    assert math.isclose(float(mixer["speedup_x"]), 1.702, abs_tol=0.001)
    assert float(full_path["change_percent"]) > 0.0
    print("Analytical and pilot-interpretation checks passed.")


if __name__ == "__main__":
    main()
