from __future__ import annotations

import tempfile
from pathlib import Path

import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from prepare_mit67 import find_data_root, validate  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        data_root = root / "indoorCVPR_09"
        images = data_root / "Images"
        manifests = root / "manifests"
        manifests.mkdir(parents=True)
        train_rows: list[str] = []
        test_rows: list[str] = []
        for class_index in range(67):
            class_name = f"class_{class_index:02d}"
            class_dir = images / class_name
            class_dir.mkdir(parents=True)
            for image_index in range(100):
                relative = f"{class_name}/image_{image_index:03d}.jpg"
                (images / relative).touch()
                (train_rows if image_index < 80 else test_rows).append(relative)
        train_list = manifests / "TrainImages.txt"
        test_list = manifests / "TestImages.txt"
        train_list.write_text("\n".join(train_rows) + "\n", encoding="utf-8")
        test_list.write_text("\n".join(test_rows) + "\n", encoding="utf-8")
        assert find_data_root(root) == data_root.resolve()
        record = validate(data_root, train_list, test_list, check_files=True)
        assert record["train_images"] == 5360
        assert record["test_images"] == 1340
        assert record["classes"] == 67
    print("MIT-67 preparation checks passed.")


if __name__ == "__main__":
    main()
