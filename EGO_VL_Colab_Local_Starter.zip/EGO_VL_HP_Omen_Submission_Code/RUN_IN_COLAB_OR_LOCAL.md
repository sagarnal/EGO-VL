# Run EGO-VL in Google Colab or on a local machine

## Before you start

You need:

1. This code folder or ZIP archive.
2. The MIT Indoor-67 image archive, normally named `indoorCVPR_09.tar`, or an already extracted folder containing `Images/`.
3. At least 12 GB of free disk space during extraction and training.
4. For GPU training, a CUDA-capable PyTorch installation. Colab users should choose **Runtime → Change runtime type → T4 GPU** before running the notebook.

The official MIT page currently exposes the split manifests but its image-archive link may fail. The helper therefore downloads only the official `TrainImages.txt` and `TestImages.txt` files. Supply the image archive from your existing copy and follow the dataset's research-use terms.

## Option A — Google Colab

1. Upload `EGO_VL_MIT67_Colab.ipynb` to Colab.
2. Select a GPU runtime.
3. Put `EGO_VL_Colab_Local_Starter.zip` and `indoorCVPR_09.tar` in `MyDrive/EGO_VL/`.
4. Run the notebook cells in order.
5. Start with the smoke test. It uses one seed and one epoch and writes only validation output.
6. Run the three-seed development cell. This trains both `ego_k16` and `full49` using a validation split derived only from the official training list.
7. Open `LOCKED_EPOCH_SUGGESTION.json`, decide and record the final epoch count, and do not change it after viewing test results.
8. Set `LOCKED_EPOCHS` in the final cell and run the official test stage once.
9. Download or retain the entire results directory in Google Drive.

Colab hardware is not an RTX 2070. Colab latency values must be labelled with the GPU model reported by `collect_system.py`. Run the same component command locally on the HP Omen for the manuscript's RTX 2070 table.

## Option B — Windows local machine

Open PowerShell in the extracted code directory.

### 1. Create an environment

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If the standard PyTorch wheel does not detect the RTX 2070, use the installation command generated for your CUDA setup at <https://pytorch.org/get-started/locally/> and then install the remaining requirements.

### 2. Prepare and verify the dataset

```powershell
python prepare_mit67.py `
  --archive "D:\datasets\indoorCVPR_09.tar" `
  --output-dir "D:\datasets\MIT67_prepared"
```

The command creates `prepared_paths.json`. Copy its three paths for the following commands.

### 3. Record the machine

```powershell
python collect_system.py --power-mode "OMEN Performance mode, AC connected" --output results/system_info.json
```

Confirm that the JSON reports the expected CPU, 16 GB RAM, and NVIDIA GeForce RTX 2070.

### 4. Run a short smoke test

```powershell
python mit67_experiment.py develop `
  --data-root "D:\datasets\MIT67_prepared\indoorCVPR_09" `
  --train-list "D:\datasets\MIT67_prepared\manifests\TrainImages.txt" `
  --test-list "D:\datasets\MIT67_prepared\manifests\TestImages.txt" `
  --seeds 20260817 --variants ego_k16 --max-epochs 1 --patience 1 `
  --batch-size 8 --num-workers 2 --output-dir results\smoke_test
```

This confirms that images, manifests, model creation, training and output writing work. Do not report the smoke-test metric as a paper result.

### 5. Run three-seed development

```powershell
.\run_hp_omen.ps1 -Stage develop `
  -DataRoot "D:\datasets\MIT67_prepared\indoorCVPR_09" `
  -TrainList "D:\datasets\MIT67_prepared\manifests\TrainImages.txt" `
  -TestList "D:\datasets\MIT67_prepared\manifests\TestImages.txt" `
  -NumWorkers 2
```

Review `results\mit67_develop\metrics_aggregate.csv` and `LOCKED_EPOCH_SUGGESTION.json`. Freeze all choices before the final stage.

### 6. Run the official final stage once

Replace `35` with the epoch count frozen after development:

```powershell
.\run_hp_omen.ps1 -Stage final `
  -DataRoot "D:\datasets\MIT67_prepared\indoorCVPR_09" `
  -TrainList "D:\datasets\MIT67_prepared\manifests\TrainImages.txt" `
  -TestList "D:\datasets\MIT67_prepared\manifests\TestImages.txt" `
  -LockedEpochs 35 -NumWorkers 2
```

### 7. Measure RTX 2070 and CPU component latency

```powershell
.\run_hp_omen.ps1 -Stage components
```

The component benchmark produces raw and summary CSV files for router-only, mixer-only and router-plus-mixer latency in CUDA FP16, CUDA FP32 and a CPU thread sweep.

### 8. Create a manuscript insertion record

```powershell
python summarize_results.py `
  --component-summary results\benchmark_cuda_fp16\component_latency_summary.csv `
  --classification-summary results\mit67_final\metrics_aggregate.csv `
  --paired-comparison results\mit67_final\paired_comparison.csv `
  --output results\manuscript_insert.json
```

## Option C — Linux or macOS local machine

Create and activate an environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Prepare the dataset:

```bash
python prepare_mit67.py \
  --archive /path/to/indoorCVPR_09.tar \
  --output-dir /path/to/MIT67_prepared
```

Run the stages:

```bash
./run_local.sh develop DATA_ROOT TRAIN_LIST TEST_LIST
./run_local.sh final DATA_ROOT TRAIN_LIST TEST_LIST LOCKED_EPOCHS
./run_local.sh components
```

On macOS without CUDA, run CPU component timing directly:

```bash
python benchmark_components.py --device cpu --precision fp32 --thread-sweep auto --output-dir results/benchmark_cpu
```

## Expected output files

- `run_config.json`: exact command settings, software version, split checks and device.
- `metrics_per_seed.csv`: one row per seed and variant.
- `metrics_aggregate.csv`: mean and standard deviation across seeds.
- `paired_comparison.csv`: paired bootstrap interval and exact McNemar comparison.
- `predictions_*.csv`: per-image probabilities and labels.
- `model_*.pt`: trained model weights.
- `training_history.csv`: per-epoch loss and validation metrics.
- `component_latency_raw.csv`: every recorded latency sample.
- `component_latency_summary.csv`: median, mean, standard deviation, p90 and p99.

Keep the raw outputs, `system_info.json`, the split manifests, and the exact code archive together. Those files are the evidence needed to reproduce the manuscript tables.
