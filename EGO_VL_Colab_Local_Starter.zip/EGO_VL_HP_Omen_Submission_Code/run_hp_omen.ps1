param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("components", "develop", "final")]
    [string]$Stage,

    [string]$Python = "python",
    [string]$DataRoot,
    [string]$TrainList,
    [string]$TestList,
    [int]$LockedEpochs = 0,
    [int]$NumWorkers = 4,
    [string]$PowerMode = "OMEN Performance mode, AC connected"
)

$ErrorActionPreference = "Stop"
$Seeds = @(20260817, 20260818, 20260819)

& $Python collect_system.py --power-mode $PowerMode --output results/system_info.json

if ($Stage -eq "components") {
    & $Python benchmark_components.py --device cuda --precision fp16 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp16
    & $Python benchmark_components.py --device cuda --precision fp32 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp32
    & $Python benchmark_components.py --device cpu --precision fp32 --thread-sweep auto --batch-size 1 --warmup 30 --iterations 200 --output-dir results/benchmark_cpu
    exit 0
}

foreach ($Required in @($DataRoot, $TrainList, $TestList)) {
    if ([string]::IsNullOrWhiteSpace($Required)) {
        throw "DataRoot, TrainList, and TestList are required for the develop and final stages."
    }
}

if ($Stage -eq "develop") {
    & $Python mit67_experiment.py develop `
        --data-root $DataRoot `
        --train-list $TrainList `
        --test-list $TestList `
        --seeds $Seeds `
        --num-workers $NumWorkers `
        --output-dir results/mit67_develop
    exit 0
}

if ($LockedEpochs -le 0) {
    throw "Final evaluation requires -LockedEpochs selected and frozen from the development stage."
}

& $Python mit67_experiment.py final `
    --data-root $DataRoot `
    --train-list $TrainList `
    --test-list $TestList `
    --locked-epochs $LockedEpochs `
    --seeds $Seeds `
    --num-workers $NumWorkers `
    --output-dir results/mit67_final
