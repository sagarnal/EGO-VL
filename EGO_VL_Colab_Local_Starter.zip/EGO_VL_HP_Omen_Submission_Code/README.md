# EGO-VL MIT-67 and HP Omen reproducibility code

This package accompanies the blind-review manuscript. It provides the executable protocol for the official MIT Indoor-67 three-seed experiment and the HP Omen component benchmarks. It also preserves the analytical attention-pair calculations and the already reported CPU-pilot timing interpretation.

The package does not contain fabricated benchmark outputs. Results generated on the target laptop should be archived under `results/` and inserted into the manuscript only after the locked final run completes.

For a guided start, open `EGO_VL_MIT67_Colab.ipynb` in Google Colab or follow `RUN_IN_COLAB_OR_LOCAL.md`. The helper `prepare_mit67.py` extracts an existing MIT Indoor-67 archive, downloads the official split manifests, and verifies the expected files before training.

## Environment

Python 3.10 or newer is recommended:

```bash
python -m pip install -r requirements.txt
```

The default visual backbone is `mobilenetv4_conv_small.e2400_r224_in1k`. Record the downloaded weight version or checksum with the experiment archive.

## Record the HP Omen configuration

Connect AC power, select the intended OMEN performance mode, close unnecessary applications, and let the laptop temperature stabilize. Then run:

```bash
python collect_system.py --power-mode "OMEN Balanced, AC connected" --output results/system_info.json
```

The script records the CPU model, physical cores, logical threads, RAM, GPU, driver, CUDA and package versions. Verify the detected information before copying it into the manuscript.

On Windows, the PowerShell wrapper provides a single entry point:

```powershell
.\run_hp_omen.ps1 -Stage components
```

## Component latency

RTX 2070, batch 1, FP16:

```bash
python benchmark_components.py --device cuda --precision fp16 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp16
```

RTX 2070, batch 1, FP32:

```bash
python benchmark_components.py --device cuda --precision fp32 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp32
```

CPU thread sweep:

```bash
python benchmark_components.py --device cpu --precision fp32 --thread-sweep auto --batch-size 1 --warmup 30 --iterations 200 --output-dir results/benchmark_cpu
```

The benchmark records raw samples and median, p90 and p99 latency for router-only, mixer-only and router-plus-mixer execution. CUDA timing uses synchronized events; CPU timing uses `perf_counter_ns`. These component measurements exclude image decoding and backbone inference.

## MIT Indoor-67 protocol

Download the dataset and the official `TrainImages.txt` and `TestImages.txt` manifests from MIT. The official split contains 5,360 training images and 1,340 test images.

Development uses only a deterministic split of the official training list:

```bash
python mit67_experiment.py develop --data-root /path/to/indoorCVPR_09 --train-list /path/to/TrainImages.txt --test-list /path/to/TestImages.txt --seeds 20260817 20260818 20260819 --output-dir results/mit67_develop
```

Freeze K, optimization settings, early stopping and the final epoch count from the development stage. Then run the official test set once:

```bash
python mit67_experiment.py final --data-root /path/to/indoorCVPR_09 --train-list /path/to/TrainImages.txt --test-list /path/to/TestImages.txt --locked-epochs 35 --seeds 20260817 20260818 20260819 --output-dir results/mit67_final
```

The final stage writes per-seed metrics, per-image predictions and probabilities, aggregate mean and standard deviation, paired bootstrap differences, and exact McNemar comparisons against the configured full-token baseline.

## CPU threads and data loading

`torch.set_num_threads(n)` controls CPU intra-operation kernels, whereas `--num-workers` controls data-loading processes. With 16 GB RAM, begin with two or four data-loading workers and select the count using a short throughput test.

## Verification

Run the analytical checks before the laptop experiment:

```bash
python -m unittest discover -s tests -v
```

`results/analytical_results.csv` contains hardware-independent node and pair calculations. `results/pilot_timing_interpretation.csv` contains only the timing values already reported in the pilot manuscript and their derived changes. New measurements must come from the generated HP Omen output folders.
