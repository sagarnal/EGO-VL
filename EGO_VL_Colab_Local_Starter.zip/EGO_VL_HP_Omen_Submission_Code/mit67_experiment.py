from __future__ import annotations

import argparse
import copy
import csv
import datetime as dt
import json
import math
import random
import statistics
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import torch
from PIL import Image
from scipy.stats import binomtest
from sklearn.metrics import accuracy_score, f1_score, log_loss
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from ego_vl.model import EGOVLClassifier


@dataclass(frozen=True)
class Item:
    relative_path: str
    class_name: str
    label: int


def read_manifest(path: Path) -> list[str]:
    lines = [line.strip().replace("\\", "/") for line in path.read_text(encoding="utf-8").splitlines()]
    return [line for line in lines if line and not line.startswith("#")]


def class_from_relative(relative: str) -> str:
    parts = Path(relative).parts
    if len(parts) < 2:
        raise ValueError(f"Manifest entry lacks a class folder: {relative}")
    if parts[0].lower() == "images" and len(parts) >= 3:
        return parts[1]
    return parts[-2]


def build_items(lines: list[str], class_to_index: dict[str, int]) -> list[Item]:
    return [Item(relative, class_from_relative(relative), class_to_index[class_from_relative(relative)]) for relative in lines]


def resolve_image(root: Path, relative: str) -> Path:
    relative_path = Path(relative)
    candidates = [root / relative_path, root / "Images" / relative_path]
    if relative_path.parts and relative_path.parts[0].lower() == "images":
        candidates.append(root.joinpath(*relative_path.parts[1:]))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return candidates[0]


def validate_official(train_items: list[Item], test_items: list[Item], allow_nonofficial: bool) -> dict:
    train_counts = Counter(item.class_name for item in train_items)
    test_counts = Counter(item.class_name for item in test_items)
    errors = []
    if len(train_counts) != 67 or len(test_counts) != 67:
        errors.append(f"expected 67 classes; found train={len(train_counts)}, test={len(test_counts)}")
    if any(value != 80 for value in train_counts.values()):
        errors.append("official training manifest must contain 80 images per class")
    if any(value != 20 for value in test_counts.values()):
        errors.append("official test manifest must contain 20 images per class")
    if set(train_counts) != set(test_counts):
        errors.append("training and test class sets differ")
    if errors and not allow_nonofficial:
        raise ValueError("; ".join(errors) + ". Pass --allow-nonofficial only for a labeled debug run.")
    return {
        "train_total": len(train_items),
        "test_total": len(test_items),
        "classes": len(set(train_counts) | set(test_counts)),
        "train_counts": dict(sorted(train_counts.items())),
        "test_counts": dict(sorted(test_counts.items())),
        "official_protocol_valid": not errors,
        "validation_errors": errors,
    }


def development_split(items: list[Item], validation_per_class: int, seed: int) -> tuple[list[Item], list[Item]]:
    by_class: dict[int, list[Item]] = defaultdict(list)
    for item in items:
        by_class[item.label].append(item)
    rng = random.Random(seed)
    train, validation = [], []
    for label in sorted(by_class):
        values = sorted(by_class[label], key=lambda item: item.relative_path)
        rng.shuffle(values)
        if validation_per_class >= len(values):
            raise ValueError("validation_per_class must be smaller than the training count in every class")
        validation.extend(values[:validation_per_class])
        train.extend(values[validation_per_class:])
    return train, validation


class MIT67Dataset(Dataset):
    def __init__(self, root: Path, items: list[Item], transform) -> None:
        self.root = root
        self.items = items
        self.transform = transform
        missing = [str(resolve_image(root, item.relative_path)) for item in items if not resolve_image(root, item.relative_path).is_file()]
        if missing:
            preview = "\n".join(missing[:5])
            raise FileNotFoundError(f"{len(missing)} manifest images were not found. First entries:\n{preview}")

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int):
        item = self.items[index]
        path = resolve_image(self.root, item.relative_path)
        with Image.open(path) as image:
            tensor = self.transform(image.convert("RGB"))
        return tensor, item.label, item.relative_path


def make_transforms(image_size: int):
    normalization = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    train = transforms.Compose([
        transforms.RandomResizedCrop(image_size, scale=(0.75, 1.0), ratio=(0.85, 1.15)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.20, contrast=0.20, saturation=0.15, hue=0.03),
        transforms.ToTensor(),
        normalization,
    ])
    evaluate = transforms.Compose([
        transforms.Resize(int(image_size * 256 / 224)),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
        normalization,
    ])
    return train, evaluate


def set_seed(seed: int, deterministic: bool) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = not deterministic
    torch.use_deterministic_algorithms(deterministic, warn_only=True)


def worker_init(worker_id: int) -> None:
    worker_seed = torch.initial_seed() % 2**32
    random.seed(worker_seed)
    np.random.seed(worker_seed)


def make_loader(dataset: Dataset, batch: int, workers: int, shuffle: bool, seed: int, device: torch.device) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch,
        shuffle=shuffle,
        num_workers=workers,
        pin_memory=device.type == "cuda",
        persistent_workers=workers > 0,
        worker_init_fn=worker_init,
        generator=generator,
    )


def ece_score(labels: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> float:
    confidence = probabilities.max(axis=1)
    prediction = probabilities.argmax(axis=1)
    correct = prediction == labels
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for lower, upper in zip(edges[:-1], edges[1:]):
        included = (confidence > lower) & (confidence <= upper)
        if included.any():
            ece += included.mean() * abs(correct[included].mean() - confidence[included].mean())
    return float(ece)


def metric_bundle(labels: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    prediction = probabilities.argmax(axis=1)
    one_hot = np.eye(probabilities.shape[1], dtype=np.float64)[labels]
    return {
        "accuracy": float(accuracy_score(labels, prediction)),
        "macro_f1": float(f1_score(labels, prediction, average="macro", zero_division=0)),
        "nll": float(log_loss(labels, probabilities, labels=np.arange(probabilities.shape[1]))),
        "brier": float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1))),
        "ece_15": ece_score(labels, probabilities, bins=15),
    }


def train_epoch(model, loader, optimizer, scaler, device, amp: bool, label_smoothing: float, k: int) -> float:
    model.train()
    total_loss = 0.0
    total = 0
    for images, labels, _ in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
            logits, _ = model(images, k_override=k, training_mask=True)
            loss = nn.functional.cross_entropy(logits, labels, label_smoothing=label_smoothing)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss += float(loss.detach()) * labels.shape[0]
        total += labels.shape[0]
    return total_loss / max(total, 1)


@torch.inference_mode()
def evaluate(model, loader, device, amp: bool, k: int) -> tuple[dict[str, float], list[str], np.ndarray, np.ndarray]:
    model.eval()
    labels_all, probabilities_all, paths_all = [], [], []
    for images, labels, paths in loader:
        images = images.to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
            logits, _ = model(images, k_override=k, training_mask=False)
        probabilities_all.append(torch.softmax(logits.float(), dim=1).cpu().numpy())
        labels_all.append(labels.numpy())
        paths_all.extend(paths)
    labels_np = np.concatenate(labels_all)
    probabilities_np = np.concatenate(probabilities_all)
    return metric_bundle(labels_np, probabilities_np), paths_all, labels_np, probabilities_np


def optimizer_for(model: nn.Module, learning_rate: float, backbone_learning_rate: float, weight_decay: float):
    backbone, new_modules = [], []
    for name, parameter in model.named_parameters():
        (backbone if name.startswith("backbone.") else new_modules).append(parameter)
    return torch.optim.AdamW(
        [
            {"params": backbone, "lr": backbone_learning_rate},
            {"params": new_modules, "lr": learning_rate},
        ],
        weight_decay=weight_decay,
    )


def write_prediction_csv(path: Path, paths: list[str], labels: np.ndarray, probabilities: np.ndarray, class_names: list[str]) -> None:
    fields = ["relative_path", "true_index", "true_class", "predicted_index", "predicted_class"] + [f"prob_{name}" for name in class_names]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for relative, label, probs in zip(paths, labels, probabilities):
            prediction = int(probs.argmax())
            row = {
                "relative_path": relative,
                "true_index": int(label),
                "true_class": class_names[int(label)],
                "predicted_index": prediction,
                "predicted_class": class_names[prediction],
            }
            row.update({f"prob_{name}": float(value) for name, value in zip(class_names, probs)})
            writer.writerow(row)


def fit_development(model, train_loader, val_loader, args, device, k: int):
    optimizer = optimizer_for(model, args.learning_rate, args.backbone_learning_rate, args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.max_epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == "cuda")
    best_state, best_metrics, best_epoch, history = None, None, 0, []
    stale = 0
    for epoch in range(1, args.max_epochs + 1):
        loss = train_epoch(model, train_loader, optimizer, scaler, device, args.amp and device.type == "cuda", args.label_smoothing, k)
        metrics, paths, labels, probabilities = evaluate(model, val_loader, device, args.amp and device.type == "cuda", k)
        history.append({"epoch": epoch, "train_loss": loss, **metrics})
        scheduler.step()
        if best_metrics is None or metrics["macro_f1"] > best_metrics["macro_f1"]:
            best_state = copy.deepcopy(model.state_dict())
            best_metrics = metrics
            best_epoch = epoch
            best_payload = (paths, labels, probabilities)
            stale = 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    model.load_state_dict(best_state)
    return best_epoch, best_metrics, best_payload, history


def fit_final(model, train_loader, args, device, k: int):
    optimizer = optimizer_for(model, args.learning_rate, args.backbone_learning_rate, args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.locked_epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == "cuda")
    history = []
    for epoch in range(1, args.locked_epochs + 1):
        loss = train_epoch(model, train_loader, optimizer, scaler, device, args.amp and device.type == "cuda", args.label_smoothing, k)
        scheduler.step()
        history.append({"epoch": epoch, "train_loss": loss})
    return history


def save_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def paired_statistics(labels: np.ndarray, a: np.ndarray, b: np.ndarray, replicates: int, seed: int) -> dict:
    a_correct = a.argmax(axis=1) == labels
    b_correct = b.argmax(axis=1) == labels
    difference = a_correct.astype(float) - b_correct.astype(float)
    rng = np.random.default_rng(seed)
    sampled = rng.integers(0, len(labels), size=(replicates, len(labels)))
    bootstrap = difference[sampled].mean(axis=1)
    b_only = int((~a_correct & b_correct).sum())
    a_only = int((a_correct & ~b_correct).sum())
    discordant = a_only + b_only
    p_value = float(binomtest(min(a_only, b_only), discordant, 0.5, alternative="two-sided").pvalue) if discordant else 1.0
    return {
        "accuracy_difference_percentage_points": float(100.0 * difference.mean()),
        "paired_bootstrap_low_percentage_points": float(100.0 * np.quantile(bootstrap, 0.025)),
        "paired_bootstrap_high_percentage_points": float(100.0 * np.quantile(bootstrap, 0.975)),
        "a_correct_b_wrong": a_only,
        "a_wrong_b_correct": b_only,
        "exact_mcnemar_p": p_value,
        "bootstrap_replicates": replicates,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Official-protocol MIT Indoor-67 EGO routing experiment")
    parser.add_argument("stage", choices=["develop", "final"])
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--train-list", type=Path, required=True)
    parser.add_argument("--test-list", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--backbone", default="mobilenetv4_conv_small.e2400_r224_in1k")
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--query-embeddings", type=Path)
    parser.add_argument("--seeds", nargs="+", type=int, default=[20260817, 20260818, 20260819])
    parser.add_argument("--split-seed", type=int, default=20260817)
    parser.add_argument("--validation-per-class", type=int, default=16)
    parser.add_argument("--variants", nargs="+", choices=["ego_k16", "full49"], default=["ego_k16", "full49"])
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--cpu-threads", type=int)
    parser.add_argument("--max-epochs", type=int, default=80)
    parser.add_argument("--locked-epochs", type=int)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--backbone-learning-rate", type=float, default=1e-5)
    parser.add_argument("--weight-decay", type=float, default=0.05)
    parser.add_argument("--label-smoothing", type=float, default=0.1)
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--amp", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--deterministic", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--allow-nonofficial", action="store_true")
    args = parser.parse_args()

    if args.stage == "final" and (args.locked_epochs is None or args.locked_epochs <= 0):
        raise SystemExit("The final stage requires a positive --locked-epochs selected before test evaluation")
    if args.cpu_threads:
        torch.set_num_threads(args.cpu_threads)
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")

    train_lines, test_lines = read_manifest(args.train_list), read_manifest(args.test_list)
    class_names = sorted({class_from_relative(value) for value in train_lines + test_lines})
    class_to_index = {name: index for index, name in enumerate(class_names)}
    train_items, test_items = build_items(train_lines, class_to_index), build_items(test_lines, class_to_index)
    protocol = validate_official(train_items, test_items, args.allow_nonofficial)
    train_transform, eval_transform = make_transforms(args.image_size)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    query_embeddings = None
    if args.query_embeddings:
        query_embeddings = torch.from_numpy(np.load(args.query_embeddings)).float()
    scope = "external_language_query_embeddings" if query_embeddings is not None else "learned_query_bank_no_external_language_encoder"
    run_config = {
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "arguments": vars(args) | {key: str(value) for key, value in vars(args).items() if isinstance(value, Path)},
        "device": str(device),
        "torch_version": torch.__version__,
        "class_names": class_names,
        "protocol": protocol,
        "model_scope": scope,
        "test_policy": "develop stage does not evaluate test; final stage refits on official train and evaluates test",
    }
    (args.output_dir / "run_config.json").write_text(json.dumps(run_config, indent=2), encoding="utf-8")

    development_train, development_val = development_split(train_items, args.validation_per_class, args.split_seed)
    (args.output_dir / "development_train_manifest.txt").write_text("\n".join(item.relative_path for item in development_train) + "\n", encoding="utf-8")
    (args.output_dir / "development_validation_manifest.txt").write_text("\n".join(item.relative_path for item in development_val) + "\n", encoding="utf-8")

    metric_rows, epoch_rows = [], []
    prediction_cache: dict[tuple[int, str], tuple[np.ndarray, np.ndarray]] = {}
    for seed in args.seeds:
        for variant in args.variants:
            set_seed(seed, args.deterministic)
            k = 16 if variant == "ego_k16" else 49
            model = EGOVLClassifier(
                num_classes=len(class_names),
                backbone_name=args.backbone,
                pretrained=not args.no_pretrained,
                k=k,
                query_embeddings=query_embeddings,
            ).to(device)
            if args.stage == "develop":
                train_dataset = MIT67Dataset(args.data_root, development_train, train_transform)
                val_dataset = MIT67Dataset(args.data_root, development_val, eval_transform)
                train_loader = make_loader(train_dataset, args.batch_size, args.num_workers, True, seed, device)
                val_loader = make_loader(val_dataset, args.batch_size, args.num_workers, False, seed, device)
                best_epoch, metrics, payload, history = fit_development(model, train_loader, val_loader, args, device, k)
                paths, labels, probabilities = payload
                split_name = "validation"
                metric_rows.append({"stage": args.stage, "split": split_name, "seed": seed, "variant": variant, "k": k, "best_epoch": best_epoch, **metrics})
            else:
                train_dataset = MIT67Dataset(args.data_root, train_items, train_transform)
                test_dataset = MIT67Dataset(args.data_root, test_items, eval_transform)
                train_loader = make_loader(train_dataset, args.batch_size, args.num_workers, True, seed, device)
                test_loader = make_loader(test_dataset, args.batch_size, args.num_workers, False, seed, device)
                history = fit_final(model, train_loader, args, device, k)
                metrics, paths, labels, probabilities = evaluate(model, test_loader, device, args.amp and device.type == "cuda", k)
                split_name = "official_test"
                metric_rows.append({"stage": args.stage, "split": split_name, "seed": seed, "variant": variant, "k": k, "best_epoch": args.locked_epochs, **metrics})
            epoch_rows.extend({"seed": seed, "variant": variant, **row} for row in history)
            prediction_cache[(seed, variant)] = (labels, probabilities)
            write_prediction_csv(args.output_dir / f"predictions_{split_name}_{variant}_seed{seed}.csv", paths, labels, probabilities, class_names)
            torch.save(model.state_dict(), args.output_dir / f"model_{args.stage}_{variant}_seed{seed}.pt")

    save_rows(args.output_dir / "metrics_per_seed.csv", metric_rows)
    save_rows(args.output_dir / "training_history.csv", epoch_rows)
    aggregate_rows = []
    for variant in args.variants:
        values = [row for row in metric_rows if row["variant"] == variant]
        if not values:
            continue
        aggregate = {"stage": args.stage, "variant": variant, "seed_count": len(values)}
        for metric in ["accuracy", "macro_f1", "nll", "brier", "ece_15"]:
            series = [float(row[metric]) for row in values]
            aggregate[f"{metric}_mean"] = statistics.fmean(series)
            aggregate[f"{metric}_std"] = statistics.stdev(series) if len(series) > 1 else 0.0
        aggregate_rows.append(aggregate)
    save_rows(args.output_dir / "metrics_aggregate.csv", aggregate_rows)

    paired_rows = []
    if {"ego_k16", "full49"}.issubset(args.variants):
        for seed in args.seeds:
            labels_a, probabilities_a = prediction_cache[(seed, "ego_k16")]
            labels_b, probabilities_b = prediction_cache[(seed, "full49")]
            if not np.array_equal(labels_a, labels_b):
                raise RuntimeError("Paired predictions do not have identical label order")
            paired_rows.append({
                "stage": args.stage,
                "seed": seed,
                "model_a": "ego_k16",
                "model_b": "full49",
                **paired_statistics(labels_a, probabilities_a, probabilities_b, args.bootstrap_replicates, seed),
            })
    save_rows(args.output_dir / "paired_comparison.csv", paired_rows)

    if args.stage == "develop":
        epochs = [int(row["best_epoch"]) for row in metric_rows if row["variant"] == "ego_k16"]
        locked = int(round(statistics.median(epochs))) if epochs else None
        (args.output_dir / "LOCKED_EPOCH_SUGGESTION.json").write_text(json.dumps({
            "suggested_locked_epochs_from_median_best_epoch": locked,
            "warning": "Freeze this and all hyperparameters before running the final stage. Do not revise it using official test results.",
        }, indent=2), encoding="utf-8")
    print(f"Completed {args.stage} stage. Results: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
