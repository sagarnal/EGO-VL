from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def as_float(row: dict[str, str], key: str) -> float:
    return float(row[key])


def main() -> None:
    parser = argparse.ArgumentParser(description="Create manuscript-ready fields from generated EGO-VL CSV files")
    parser.add_argument("--component-summary", type=Path, required=True)
    parser.add_argument("--classification-summary", type=Path)
    parser.add_argument("--paired-comparison", type=Path)
    parser.add_argument("--output", type=Path, default=Path("results/manuscript_insert.json"))
    args = parser.parse_args()

    component_rows = read_csv(args.component_summary)
    payload: dict[str, object] = {"component_latency": component_rows}
    if args.classification_summary:
        payload["classification"] = read_csv(args.classification_summary)
    if args.paired_comparison:
        payload["paired_comparison"] = read_csv(args.paired_comparison)

    mixer_16 = [row for row in component_rows if row["component"] == "mixer_only" and int(row["k_local"]) == 16]
    mixer_49 = [row for row in component_rows if row["component"] == "mixer_only" and int(row["k_local"]) == 49]
    if mixer_16 and mixer_49:
        candidate_16 = min(mixer_16, key=lambda row: as_float(row, "median_ms"))
        matching_49 = [
            row for row in mixer_49
            if row.get("device") == candidate_16.get("device")
            and row.get("precision") == candidate_16.get("precision")
            and row.get("cpu_intraop_threads") == candidate_16.get("cpu_intraop_threads")
        ]
        if matching_49:
            full = matching_49[0]
            k16_ms, full_ms = as_float(candidate_16, "median_ms"), as_float(full, "median_ms")
            payload["derived_mixer_k16_vs_full"] = {
                "k16_median_ms": k16_ms,
                "full49_median_ms": full_ms,
                "latency_reduction_percent": 100.0 * (full_ms - k16_ms) / full_ms,
                "speedup_x": full_ms / k16_ms,
                "matched_device": candidate_16.get("device"),
                "matched_precision": candidate_16.get("precision"),
                "matched_cpu_intraop_threads": candidate_16.get("cpu_intraop_threads"),
            }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()

