from __future__ import annotations

import argparse
import datetime as dt
import importlib.metadata
import json
import os
import platform
import subprocess
from pathlib import Path
from typing import Any, Optional


def run_text(command: list[str]) -> Optional[str]:
    try:
        result = subprocess.run(command, check=False, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None
    value = result.stdout.strip()
    return value or None


def cpu_name() -> str:
    name = platform.processor().strip()
    if name and name.lower() not in {"unknown", "amd64", "x86_64"}:
        return name
    if platform.system() == "Windows":
        value = run_text([
            "powershell", "-NoProfile", "-Command",
            "(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name)",
        ])
        if value:
            return value
    if platform.system() == "Linux":
        try:
            for line in Path("/proc/cpuinfo").read_text(errors="ignore").splitlines():
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
        except OSError:
            pass
    return name or "not detected"


def physical_cores() -> Optional[int]:
    try:
        import psutil

        value = psutil.cpu_count(logical=False)
        if value:
            return int(value)
    except ImportError:
        pass
    if platform.system() == "Windows":
        value = run_text([
            "powershell", "-NoProfile", "-Command",
            "($p=Get-CimInstance Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum",
        ])
        try:
            return int(value) if value else None
        except ValueError:
            return None
    if platform.system() == "Linux":
        value = run_text(["lscpu", "-p=CORE,SOCKET"])
        if value:
            pairs = {line for line in value.splitlines() if line and not line.startswith("#")}
            return len(pairs) or None
    return None


def total_ram_bytes() -> Optional[int]:
    try:
        import psutil

        return int(psutil.virtual_memory().total)
    except ImportError:
        pass
    if platform.system() == "Windows":
        value = run_text([
            "powershell", "-NoProfile", "-Command",
            "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory",
        ])
        try:
            return int(value) if value else None
        except ValueError:
            return None
    try:
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
    except (AttributeError, ValueError, OSError):
        return None


def package_versions() -> dict[str, Optional[str]]:
    result = {}
    for package in ["torch", "torchvision", "timm", "numpy", "pandas", "scikit-learn", "scipy", "Pillow", "psutil"]:
        try:
            result[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            result[package] = None
    return result


def nvidia_smi() -> list[dict[str, Any]]:
    query = "name,memory.total,driver_version,temperature.gpu,power.limit"
    value = run_text(["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"])
    if not value:
        return []
    devices = []
    for line in value.splitlines():
        parts = [part.strip() for part in line.split(",")]
        if len(parts) == 5:
            devices.append({
                "name": parts[0],
                "memory_total_mib": parts[1],
                "driver_version": parts[2],
                "temperature_c_at_capture": parts[3],
                "power_limit_w": parts[4],
            })
    return devices


def torch_runtime() -> dict[str, Any]:
    try:
        import torch
    except ImportError:
        return {"available": False}
    data: dict[str, Any] = {
        "available": True,
        "version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_runtime": torch.version.cuda,
        "cpu_intraop_threads": torch.get_num_threads(),
        "cpu_interop_threads": torch.get_num_interop_threads(),
    }
    if torch.cuda.is_available():
        data["cudnn_version"] = torch.backends.cudnn.version()
        data["gpus"] = []
        for index in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(index)
            data["gpus"].append({
                "index": index,
                "name": props.name,
                "total_memory_bytes": int(props.total_memory),
                "compute_capability": f"{props.major}.{props.minor}",
                "multiprocessor_count": int(props.multi_processor_count),
            })
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description="Record hardware/software identity before EGO-VL experiments")
    parser.add_argument("--power-mode", default="not recorded", help="Operator-observed power/thermal mode")
    parser.add_argument("--output", type=Path, default=Path("results/system_info.json"))
    args = parser.parse_args()

    ram = total_ram_bytes()
    record = {
        "captured_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "operator_power_mode": args.power_mode,
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "python": platform.python_version(),
        },
        "cpu": {
            "name": cpu_name(),
            "physical_cores": physical_cores(),
            "logical_threads": os.cpu_count(),
        },
        "memory": {
            "total_bytes": ram,
            "total_gib": round(ram / 2**30, 3) if ram else None,
        },
        "nvidia_smi": nvidia_smi(),
        "torch_runtime": torch_runtime(),
        "package_versions": package_versions(),
        "user_reported_target": {
            "device_family": "HP Omen laptop",
            "ram_gib": 16,
            "gpu": "NVIDIA GeForce RTX 2070",
            "gpu_memory_gib": 8,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps(record, indent=2))
    print(f"\nSaved: {args.output.resolve()}")


if __name__ == "__main__":
    main()

