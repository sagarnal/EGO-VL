from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, Optional

import torch
from torch import Tensor, nn
import torch.nn.functional as F


def attention_pair_stats(k_local: int, full_local: int = 49) -> Dict[str, float]:
    """Return ordered attention-pair counts including one preserved global token."""
    if not 0 <= k_local <= full_local:
        raise ValueError(f"k_local must be in [0, {full_local}], received {k_local}")
    pairs = (k_local + 1) ** 2
    full_pairs = (full_local + 1) ** 2
    reduction = 100.0 * (full_pairs - pairs) / full_pairs
    return {
        "k_local": int(k_local),
        "tokens_including_global": int(k_local + 1),
        "ordered_attention_pairs": int(pairs),
        "pair_reduction_vs_full_percent": float(reduction),
    }


def _minmax_unit(x: Tensor, dim: int = -1, eps: float = 1e-8) -> Tensor:
    lo = x.amin(dim=dim, keepdim=True)
    hi = x.amax(dim=dim, keepdim=True)
    return (x - lo) / (hi - lo + eps)


def grid_positions(side: int, device: torch.device, dtype: torch.dtype) -> Tensor:
    axis = torch.linspace(0.0, 1.0, side, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    return torch.stack((xx, yy), dim=-1).reshape(side * side, 2)


@dataclass(frozen=True)
class RouterWeights:
    relevance: float = 0.40
    structure: float = 0.30
    objectness: float = 0.20
    diversity: float = 0.10

    def validate(self) -> None:
        values = [self.relevance, self.structure, self.objectness, self.diversity]
        if any(v < 0 for v in values):
            raise ValueError("Router weights must be non-negative")
        if not math.isclose(sum(values), 1.0, abs_tol=1e-6):
            raise ValueError(f"Router weights must sum to 1.0, received {sum(values):.6f}")


class EdgeGuidedRouter(nn.Module):
    """Query/structure/objectness router with deterministic greedy spatial diversity.

    Inference uses the manuscript's iterative rule. Training can use a straight-through
    top-k mask over the differentiable base score. The training approximation is exposed
    explicitly because a hard greedy diversity loop is not differentiable.
    """

    def __init__(self, dim: int = 256, weights: RouterWeights = RouterWeights()) -> None:
        super().__init__()
        weights.validate()
        self.weights = weights
        self.token_projection = nn.Linear(dim, dim, bias=False)
        self.query_projection = nn.Linear(dim, dim, bias=False)
        self.objectness = nn.Sequential(
            nn.LayerNorm(dim), nn.Linear(dim, max(dim // 4, 16)), nn.GELU(), nn.Linear(max(dim // 4, 16), 1)
        )

    def score_components(self, tokens: Tensor, query: Tensor, structure: Tensor) -> Dict[str, Tensor]:
        if tokens.ndim != 3:
            raise ValueError("tokens must have shape [batch, local_tokens, dim]")
        if query.ndim != 2 or query.shape[0] != tokens.shape[0]:
            raise ValueError("query must have shape [batch, dim]")
        if structure.ndim == 3:
            structure = structure.mean(dim=-1)
        if structure.shape != tokens.shape[:2]:
            raise ValueError("structure must have shape [batch, local_tokens] or [..., channels]")

        z = F.normalize(self.token_projection(tokens), dim=-1)
        q = F.normalize(self.query_projection(query), dim=-1).unsqueeze(1)
        relevance = ((z * q).sum(dim=-1) + 1.0) * 0.5
        structure_u = _minmax_unit(structure)
        objectness = torch.sigmoid(self.objectness(tokens).squeeze(-1))
        base = (
            self.weights.relevance * relevance
            + self.weights.structure * structure_u
            + self.weights.objectness * objectness
        )
        return {
            "relevance": relevance,
            "structure": structure_u,
            "objectness": objectness,
            "base": base,
        }

    def _greedy_indices(self, base: Tensor, positions: Tensor, k: int) -> Tensor:
        batch, n = base.shape
        if positions.ndim == 2:
            positions = positions.unsqueeze(0).expand(batch, -1, -1)
        if positions.shape != (batch, n, 2):
            raise ValueError("positions must have shape [local_tokens, 2] or [batch, local_tokens, 2]")
        if k >= n:
            return torch.arange(n, device=base.device).unsqueeze(0).expand(batch, -1)

        selected = []
        unavailable = torch.zeros((batch, n), dtype=torch.bool, device=base.device)
        min_distance = torch.ones_like(base)
        batch_index = torch.arange(batch, device=base.device)
        for _ in range(k):
            total = base + self.weights.diversity * min_distance
            total = total.masked_fill(unavailable, torch.finfo(total.dtype).min)
            idx = total.argmax(dim=1)  # torch.argmax resolves exact ties by lowest index.
            selected.append(idx)
            unavailable[batch_index, idx] = True
            chosen = positions[batch_index, idx].unsqueeze(1)
            distance = torch.linalg.vector_norm(positions - chosen, dim=-1) / math.sqrt(2.0)
            min_distance = torch.minimum(min_distance, distance)
        return torch.stack(selected, dim=1)

    def _straight_through_mask(self, base: Tensor, k: int, temperature: float) -> tuple[Tensor, Tensor]:
        k = min(k, base.shape[1])
        indices = torch.topk(base, k=k, dim=1, sorted=True).indices
        hard = torch.zeros_like(base).scatter(1, indices, 1.0)
        soft = (k * torch.softmax(base / max(temperature, 1e-4), dim=1)).clamp(max=1.0)
        mask = hard + soft - soft.detach()
        return indices, mask

    def forward(
        self,
        tokens: Tensor,
        query: Tensor,
        structure: Tensor,
        positions: Tensor,
        k: int,
        training_mask: bool = False,
        temperature: float = 0.5,
    ) -> Dict[str, Tensor]:
        if k <= 0:
            raise ValueError("k must be positive")
        components = self.score_components(tokens, query, structure)
        if training_mask and self.training:
            indices, mask = self._straight_through_mask(components["base"], k, temperature)
        else:
            indices = self._greedy_indices(components["base"], positions, min(k, tokens.shape[1]))
            mask = torch.zeros_like(components["base"]).scatter(1, indices, 1.0)
        gather_idx = indices.unsqueeze(-1).expand(-1, -1, tokens.shape[-1])
        selected_tokens = tokens.gather(1, gather_idx)
        return {**components, "indices": indices, "mask": mask, "selected_tokens": selected_tokens}


class RelationAttentionBlock(nn.Module):
    def __init__(self, dim: int = 256, heads: int = 4, mlp_ratio: float = 2.0, dropout: float = 0.0) -> None:
        super().__init__()
        if dim % heads:
            raise ValueError("dim must be divisible by heads")
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.norm1 = nn.LayerNorm(dim)
        self.qkv = nn.Linear(dim, 3 * dim)
        self.output = nn.Linear(dim, dim)
        self.relation_bias = nn.Sequential(nn.Linear(3, 32), nn.GELU(), nn.Linear(32, heads))
        self.query_gate = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, heads), nn.Sigmoid())
        hidden = int(dim * mlp_ratio)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(nn.Linear(dim, hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden, dim))

    def forward(self, h: Tensor, positions: Tensor, query: Tensor) -> Tensor:
        batch, tokens, dim = h.shape
        x = self.norm1(h)
        qkv = self.qkv(x).reshape(batch, tokens, 3, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        logits = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)

        delta = positions.unsqueeze(2) - positions.unsqueeze(1)
        distance = torch.linalg.vector_norm(delta, dim=-1, keepdim=True)
        rel = torch.cat((delta, distance), dim=-1)
        rel_bias = self.relation_bias(rel).permute(0, 3, 1, 2)
        gate = 0.5 + self.query_gate(query).unsqueeze(-1).unsqueeze(-1)
        attention = torch.softmax(logits + gate * rel_bias, dim=-1)
        mixed = torch.matmul(attention, v).transpose(1, 2).reshape(batch, tokens, dim)
        h = h + self.output(mixed)
        h = h + self.mlp(self.norm2(h))
        return h


class RelationMixer(nn.Module):
    def __init__(self, dim: int = 256, heads: int = 4, layers: int = 2) -> None:
        super().__init__()
        self.blocks = nn.ModuleList([RelationAttentionBlock(dim=dim, heads=heads) for _ in range(layers)])
        self.final_norm = nn.LayerNorm(dim)

    def forward(self, tokens: Tensor, positions: Tensor, query: Tensor) -> Tensor:
        h = tokens
        for block in self.blocks:
            h = block(h, positions, query)
        return self.final_norm(h)


class StructuralPrior(nn.Module):
    """Fixed Sobel magnitude and local variance pooled to the token grid."""

    def __init__(self, grid: int = 7) -> None:
        super().__init__()
        sx = torch.tensor([[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]])
        sy = sx.t()
        self.register_buffer("sobel_x", sx.reshape(1, 1, 3, 3), persistent=False)
        self.register_buffer("sobel_y", sy.reshape(1, 1, 3, 3), persistent=False)
        self.grid = grid

    def forward(self, images: Tensor) -> Tensor:
        gray = images.mean(dim=1, keepdim=True)
        gx = F.conv2d(gray, self.sobel_x.to(dtype=images.dtype), padding=1)
        gy = F.conv2d(gray, self.sobel_y.to(dtype=images.dtype), padding=1)
        edge = torch.sqrt(gx.square() + gy.square() + 1e-8)
        mean = F.avg_pool2d(gray, kernel_size=5, stride=1, padding=2)
        mean_sq = F.avg_pool2d(gray.square(), kernel_size=5, stride=1, padding=2)
        variance = (mean_sq - mean.square()).clamp_min(0.0)
        edge = F.adaptive_avg_pool2d(edge, (self.grid, self.grid)).flatten(1)
        variance = F.adaptive_avg_pool2d(variance, (self.grid, self.grid)).flatten(1)
        return 0.65 * _minmax_unit(edge) + 0.35 * _minmax_unit(variance)


class EGOVLClassifier(nn.Module):
    """Compact EGO-VL classifier for the official MIT-67 experiment.

    The class-query bank can be replaced with externally generated language embeddings.
    Without external embeddings it is a learned query bank and results must be described
    as an EGO routing classifier, not as a fully pretrained vision-language system.
    """

    def __init__(
        self,
        num_classes: int = 67,
        backbone_name: str = "mobilenetv4_conv_small.e2400_r224_in1k",
        pretrained: bool = True,
        dim: int = 256,
        heads: int = 4,
        layers: int = 2,
        grid: int = 7,
        k: int = 16,
        query_embeddings: Optional[Tensor] = None,
    ) -> None:
        super().__init__()
        try:
            import timm
        except ImportError as exc:
            raise RuntimeError("Install timm from requirements.txt before constructing EGOVLClassifier") from exc

        self.backbone = timm.create_model(backbone_name, pretrained=pretrained, features_only=True)
        channels = int(self.backbone.feature_info.channels()[-1])
        self.project = nn.Sequential(nn.Conv2d(channels, dim, 1), nn.BatchNorm2d(dim), nn.GELU())
        self.grid = grid
        self.k = k
        self.num_classes = num_classes
        self.structure = StructuralPrior(grid=grid)
        self.router = EdgeGuidedRouter(dim=dim)
        self.mixer = RelationMixer(dim=dim, heads=heads, layers=layers)
        self.classifier = nn.Linear(dim, num_classes)
        if query_embeddings is None:
            self.query_bank = nn.Parameter(torch.randn(num_classes, dim) * 0.02)
        else:
            if query_embeddings.shape[0] != num_classes:
                raise ValueError("query_embeddings first dimension must equal num_classes")
            self.query_bank = nn.Parameter(query_embeddings.float())
        self.query_adapter = nn.Linear(self.query_bank.shape[1], dim, bias=False)

    def _context_query(self, global_token: Tensor) -> Tensor:
        bank = F.normalize(self.query_adapter(self.query_bank), dim=-1)
        weights = torch.softmax(F.normalize(global_token, dim=-1) @ bank.t(), dim=-1)
        return weights @ bank

    def forward(self, images: Tensor, k_override: Optional[int] = None, training_mask: bool = False) -> tuple[Tensor, Dict[str, Tensor]]:
        fmap = self.backbone(images)[-1]
        fmap = F.adaptive_avg_pool2d(self.project(fmap), (self.grid, self.grid))
        local = fmap.flatten(2).transpose(1, 2)
        global_token = local.mean(dim=1)
        query = self._context_query(global_token)
        structure = self.structure(images)
        positions = grid_positions(self.grid, images.device, local.dtype)
        k = min(int(k_override if k_override is not None else self.k), local.shape[1])
        routed = self.router(local, query, structure, positions, k=k, training_mask=training_mask)
        selected = routed["selected_tokens"]
        pos_batch = positions.unsqueeze(0).expand(images.shape[0], -1, -1)
        pos_idx = routed["indices"].unsqueeze(-1).expand(-1, -1, 2)
        selected_positions = pos_batch.gather(1, pos_idx)
        global_position = torch.full((images.shape[0], 1, 2), 0.5, device=images.device, dtype=local.dtype)
        nodes = torch.cat((global_token.unsqueeze(1), selected), dim=1)
        node_positions = torch.cat((global_position, selected_positions), dim=1)
        mixed = self.mixer(nodes, node_positions, query)
        logits = self.classifier(mixed[:, 0])
        aux = {**routed, "query": query, "node_positions": node_positions, "mixed": mixed}
        return logits, aux
