from __future__ import annotations

import argparse
import json
import shutil
import tarfile
import urllib.request
from collections import Counter
from pathlib import Path


TRAIN_URL = "https://web.mit.edu/torralba/www/TrainImages.txt"
TEST_URL = "https://web.mit.edu/torralba/www/TestImages.txt"


def safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    destination_resolved = destination.resolve()
    with tarfile.open(archive) as handle:
        for member in handle.getmembers():
            target = (destination / member.name).resolve()
            if destination_resolved not in target.parents and target != destination_resolved:
                raise ValueError(f"Unsafe archive path: {member.name}")
        try:
            handle.extractall(destination, filter="data")
        except TypeError:  # Python < 3.12
            handle.extractall(destination)


def download(url: str, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url, timeout=60) as response, output.open("wb") as target:
        shutil.copyfileobj(response, target)


def find_data_root(search_root: Path) -> Path:
    direct = [search_root, search_root / "indoorCVPR_09"]
    candidates = direct + [path.parent for path in search_root.rglob("Images") if path.is_dir()]
    seen: set[Path] = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        images = candidate / "Images"
        if images.is_dir() and len([path for path in images.iterdir() if path.is_dir()]) >= 67:
            return candidate
    raise FileNotFoundError(f"Could not find an MIT-67 Images directory under {search_root}")


def read_manifest(path: Path) -> list[str]:
    return [line.strip().replace("\\", "/") for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def class_name(relative: str) -> str:
    parts = Path(relative).parts
    return parts[1] if parts and parts[0].lower() == "images" else parts[-2]


def resolve_image(data_root: Path, relative: str) -> Path:
    relative_path = Path(relative)
    candidates = [data_root / relative_path, data_root / "Images" / relative_path]
    if relative_path.parts and relative_path.parts[0].lower() == "images":
        candidates.append(data_root.joinpath(*relative_path.parts[1:]))
    return next((path for path in candidates if path.is_file()), candidates[0])


def validate(data_root: Path, train_list: Path, test_list: Path, check_files: bool) -> dict:
    train, test = read_manifest(train_list), read_manifest(test_list)
    train_counts = Counter(class_name(value) for value in train)
    test_counts = Counter(class_name(value) for value in test)
    errors: list[str] = []
    if len(train) != 5360:
        errors.append(f"training manifest contains {len(train)} entries; expected 5360")
    if len(test) != 1340:
        errors.append(f"test manifest contains {len(test)} entries; expected 1340")
    if len(train_counts) != 67 or any(count != 80 for count in train_counts.values()):
        errors.append("training manifest is not 80 images x 67 classes")
    if len(test_counts) != 67 or any(count != 20 for count in test_counts.values()):
        errors.append("test manifest is not 20 images x 67 classes")
    if set(train_counts) != set(test_counts):
        errors.append("training and test class sets differ")
    missing: list[str] = []
    if check_files:
        missing = [value for value in train + test if not resolve_image(data_root, value).is_file()]
        if missing:
            errors.append(f"{len(missing)} manifest images are missing")
    if errors:
        preview = "\n".join(missing[:10])
        detail = "; ".join(errors)
        if preview:
            detail += f"\nFirst missing paths:\n{preview}"
        raise ValueError(detail)
    return {
        "data_root": str(data_root.resolve()),
        "train_list": str(train_list.resolve()),
        "test_list": str(test_list.resolve()),
        "train_images": len(train),
        "test_images": len(test),
        "classes": len(train_counts),
        "all_manifest_files_present": check_files,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract and validate MIT Indoor-67 for the EGO-VL experiment")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for extracted data and manifests")
    parser.add_argument("--archive", type=Path, help="Path to indoorCVPR_09.tar")
    parser.add_argument("--data-root", type=Path, help="Existing directory that contains Images/")
    parser.add_argument("--download-manifests", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--check-files", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--record", type=Path, help="JSON path; defaults to OUTPUT_DIR/prepared_paths.json")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.archive:
        if not args.archive.is_file():
            raise FileNotFoundError(args.archive)
        print(f"Extracting {args.archive} to {args.output_dir} ...")
        safe_extract(args.archive, args.output_dir)

    search_root = args.data_root if args.data_root else args.output_dir
    data_root = find_data_root(search_root)
    manifest_dir = args.output_dir / "manifests"
    train_list = manifest_dir / "TrainImages.txt"
    test_list = manifest_dir / "TestImages.txt"
    if args.download_manifests:
        print("Downloading official MIT split manifests ...")
        download(TRAIN_URL, train_list)
        download(TEST_URL, test_list)
    elif not train_list.is_file() or not test_list.is_file():
        raise FileNotFoundError("Manifest files are absent; enable --download-manifests")

    record = validate(data_root, train_list, test_list, args.check_files)
    record_path = args.record or args.output_dir / "prepared_paths.json"
    record_path.parent.mkdir(parents=True, exist_ok=True)
    record_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps(record, indent=2))
    print(f"Dataset validation passed. Paths saved to {record_path.resolve()}")


if __name__ == "__main__":
    main()
