from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import math
import os
import platform
import statistics
import time
from pathlib import Path
from typing import Callable, Iterable

import torch

from ego_vl.model import EdgeGuidedRouter, RelationMixer, attention_pair_stats, grid_positions


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("Cannot compute a percentile of an empty list")
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def timed_cpu(function: Callable[[], object], warmup: int, iterations: int) -> list[float]:
    with torch.inference_mode():
        for _ in range(warmup):
            function()
        samples = []
        for _ in range(iterations):
            start = time.perf_counter_ns()
            function()
            samples.append((time.perf_counter_ns() - start) / 1e6)
    return samples


def timed_cuda(function: Callable[[], object], warmup: int, iterations: int) -> list[float]:
    with torch.inference_mode():
        for _ in range(warmup):
            function()
        torch.cuda.synchronize()
        samples = []
        for _ in range(iterations):
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            function()
            end.record()
            torch.cuda.synchronize()
            samples.append(float(start.elapsed_time(end)))
    return samples


def auto_threads() -> list[int]:
    logical = os.cpu_count() or 1
    physical = None
    try:
        import psutil

        physical = psutil.cpu_count(logical=False)
    except ImportError:
        pass
    values = {1, 2, 4, logical}
    if physical:
        values.add(int(physical))
    return sorted(value for value in values if 1 <= value <= logical)


def parse_threads(value: str) -> list[int]:
    if value.lower() == "auto":
        return auto_threads()
    parsed = sorted({int(item) for item in value.split(",")})
    if any(item <= 0 for item in parsed):
        raise ValueError("Thread counts must be positive")
    return parsed


def build_inputs(batch: int, dim: int, device: torch.device, dtype: torch.dtype):
    generator = torch.Generator(device=device).manual_seed(20260817)
    local = torch.randn(batch, 49, dim, generator=generator, device=device, dtype=dtype)
    query = torch.randn(batch, dim, generator=generator, device=device, dtype=dtype)
    structure = torch.rand(batch, 49, generator=generator, device=device, dtype=dtype)
    positions = grid_positions(7, device, dtype)
    return local, query, structure, positions


def aggregate_row(samples: list[float], metadata: dict) -> dict:
    return {
        **metadata,
        "sample_count": len(samples),
        "median_ms": statistics.median(samples),
        "mean_ms": statistics.fmean(samples),
        "std_ms": statistics.stdev(samples) if len(samples) > 1 else 0.0,
        "p90_ms": percentile(samples, 0.90),
        "p99_ms": percentile(samples, 0.99),
        "min_ms": min(samples),
        "max_ms": max(samples),
    }


def benchmark_one(
    device: torch.device,
    dtype: torch.dtype,
    batch_size: int,
    dim: int,
    heads: int,
    layers: int,
    k: int,
    warmup: int,
    iterations: int,
) -> tuple[list[dict], list[dict]]:
    router = EdgeGuidedRouter(dim=dim).to(device=device, dtype=dtype).eval()
    mixer = RelationMixer(dim=dim, heads=heads, layers=layers).to(device=device, dtype=dtype).eval()
    local, query, structure, positions = build_inputs(batch_size, dim, device, dtype)

    def route():
        return router(local, query, structure, positions, k=k, training_mask=False)

    routed = route()
    selected = routed["selected_tokens"]
    pos_batch = positions.unsqueeze(0).expand(batch_size, -1, -1)
    pos_idx = routed["indices"].unsqueeze(-1).expand(-1, -1, 2)
    selected_positions = pos_batch.gather(1, pos_idx)
    global_token = local.mean(dim=1, keepdim=True)
    global_position = torch.full((batch_size, 1, 2), 0.5, device=device, dtype=dtype)
    nodes = torch.cat((global_token, selected), dim=1)
    node_positions = torch.cat((global_position, selected_positions), dim=1)

    def mix():
        return mixer(nodes, node_positions, query)

    def combined():
        current = route()
        current_idx = current["indices"].unsqueeze(-1).expand(-1, -1, 2)
        current_positions = pos_batch.gather(1, current_idx)
        current_nodes = torch.cat((global_token, current["selected_tokens"]), dim=1)
        current_node_positions = torch.cat((global_position, current_positions), dim=1)
        return mixer(current_nodes, current_node_positions, query)

    timer = timed_cuda if device.type == "cuda" else timed_cpu
    rows = []
    raw = []
    for component, function in [("router_only", route), ("mixer_only", mix), ("router_plus_mixer", combined)]:
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        samples = timer(function, warmup, iterations)
        peak_memory = int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else None
        metadata = {
            "component": component,
            "device": device.type,
            "precision": str(dtype).replace("torch.", ""),
            "batch_size": batch_size,
            "k_local": k,
            "tokens_including_global": k + 1,
            "ordered_attention_pairs": (k + 1) ** 2,
            "peak_cuda_memory_bytes": peak_memory,
        }
        rows.append(aggregate_row(samples, metadata))
        raw.extend({**metadata, "iteration": index, "latency_ms": value} for index, value in enumerate(samples))
    return rows, raw


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure EGO-VL router and relation-mixer component latency")
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--precision", choices=["fp32", "fp16"], default="fp32")
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--dim", type=int, default=256)
    parser.add_argument("--heads", type=int, default=4)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--k-values", type=int, nargs="+", default=[8, 12, 16, 24, 49])
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--iterations", type=int, default=300)
    parser.add_argument("--thread-sweep", default="auto", help="CPU only: 'auto' or comma-separated intra-op counts")
    parser.add_argument("--output-dir", type=Path, default=Path("results/component_benchmark"))
    args = parser.parse_args()

    if args.device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA was requested but torch.cuda.is_available() is false")
    if args.precision == "fp16" and args.device != "cuda":
        raise SystemExit("This package permits FP16 timing only on CUDA; use FP32 for the CPU sweep")
    if any(k < 1 or k > 49 for k in args.k_values):
        raise SystemExit("Every K must be between 1 and 49")

    device = torch.device(args.device)
    dtype = torch.float16 if args.precision == "fp16" else torch.float32
    thread_values = parse_threads(args.thread_sweep) if args.device == "cpu" else [torch.get_num_threads()]
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    all_aggregate: list[dict] = []
    all_raw: list[dict] = []
    for threads in thread_values:
        if args.device == "cpu":
            torch.set_num_threads(threads)
        for k in args.k_values:
            aggregate, raw = benchmark_one(
                device=device,
                dtype=dtype,
                batch_size=args.batch_size,
                dim=args.dim,
                heads=args.heads,
                layers=args.layers,
                k=k,
                warmup=args.warmup,
                iterations=args.iterations,
            )
            for row in aggregate:
                row["cpu_intraop_threads"] = threads if args.device == "cpu" else None
                row["cpu_interop_threads"] = torch.get_num_interop_threads()
            for row in raw:
                row["cpu_intraop_threads"] = threads if args.device == "cpu" else None
                row["cpu_interop_threads"] = torch.get_num_interop_threads()
            all_aggregate.extend(aggregate)
            all_raw.extend(raw)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "component_latency_summary.csv", all_aggregate)
    write_csv(args.output_dir / "component_latency_raw.csv", all_raw)
    analytical = [attention_pair_stats(k) for k in args.k_values]
    write_csv(args.output_dir / "analytical_pair_counts.csv", analytical)
    metadata = {
        "captured_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "platform": platform.platform(),
        "torch_version": torch.__version__,
        "device": str(device),
        "device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else platform.processor(),
        "precision": args.precision,
        "warmup": args.warmup,
        "iterations": args.iterations,
        "batch_size": args.batch_size,
        "dim": args.dim,
        "heads": args.heads,
        "layers": args.layers,
        "k_values": args.k_values,
        "cpu_thread_values": thread_values if args.device == "cpu" else None,
        "timing_scope": "random-input router/mixer component benchmark; excludes backbone, image decode, and transfer",
    }
    (args.output_dir / "benchmark_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))
    print(f"Saved aggregate and raw results to {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
