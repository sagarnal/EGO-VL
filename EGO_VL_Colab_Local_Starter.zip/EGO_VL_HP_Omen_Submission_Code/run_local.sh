#!/usr/bin/env bash
set -euo pipefail

stage="${1:-}"
python_bin="${PYTHON_BIN:-python3}"

if [[ -z "$stage" ]]; then
  echo "Usage: $0 {components|develop|final} [data_root train_list test_list [locked_epochs]]"
  exit 2
fi

"$python_bin" collect_system.py --power-mode "record locally before publication" --output results/system_info.json

if [[ "$stage" == "components" ]]; then
  "$python_bin" benchmark_components.py --device cuda --precision fp16 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp16
  "$python_bin" benchmark_components.py --device cuda --precision fp32 --batch-size 1 --warmup 50 --iterations 300 --output-dir results/benchmark_cuda_fp32
  "$python_bin" benchmark_components.py --device cpu --precision fp32 --thread-sweep auto --batch-size 1 --warmup 30 --iterations 200 --output-dir results/benchmark_cpu
  exit 0
fi

data_root="${2:-}"
train_list="${3:-}"
test_list="${4:-}"
if [[ -z "$data_root" || -z "$train_list" || -z "$test_list" ]]; then
  echo "develop/final requires: data_root train_list test_list"
  exit 2
fi

seeds=(20260817 20260818 20260819)
if [[ "$stage" == "develop" ]]; then
  "$python_bin" mit67_experiment.py develop \
    --data-root "$data_root" --train-list "$train_list" --test-list "$test_list" \
    --seeds "${seeds[@]}" --num-workers 4 --output-dir results/mit67_develop
  exit 0
fi

if [[ "$stage" == "final" ]]; then
  locked_epochs="${5:-0}"
  if [[ "$locked_epochs" -le 0 ]]; then
    echo "final requires a positive locked_epochs argument selected from development"
    exit 2
  fi
  "$python_bin" mit67_experiment.py final \
    --data-root "$data_root" --train-list "$train_list" --test-list "$test_list" \
    --locked-epochs "$locked_epochs" --seeds "${seeds[@]}" --num-workers 4 \
    --output-dir results/mit67_final
  exit 0
fi

echo "Unknown stage: $stage"
exit 2
